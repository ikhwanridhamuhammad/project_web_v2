<?php 
	//=================================================
	session_start();
	//======================================================
	$_SESSION["_ra_tgl_start"] = "";
	$_SESSION["_ra_tgl_end"] = "";
	$_SESSION["_ra_outlet"] = "";
	$_SESSION["_ra_karyawan"] = "";
	//==============================================
	$_SESSION["_shift_sn_tgl"] = "";
	$_SESSION["_shift_sn_outlet"] = "";
	//==============================================
	$_SESSION["_po_tahun_bulan"] = "";
	$_SESSION["_po_outlet"] = "";
	$_SESSION["_po_karyawan"] = "";
	$_SESSION["_po_sn_tahun_bulan"] = "";
	$_SESSION["_po_sn_outlet"] = "";
	$_SESSION["_po_sn_karyawan"] = "";
	$_SESSION["_ra_edit_absensi"] = "";
	$_SESSION["_ssn_tahun_bulan"] = "";
	$_SESSION["_ssn_outlet"] = "";
	$_SESSION["_dsn_tgl"] = "";
	$_SESSION["_dsn_outlet"] = "";
	$_SESSION["_dsn_shift"] = "";
	$_SESSION["_so_outlet"] = "";
	$_SESSION["_ss_outlet"] = "";
	$_SESSION["_ss_shift"] = "";
	//==============================================
	$_SESSION["_su_add_action"] = "";
	$_SESSION["_su_add_nik"] = "";
	$_SESSION["_su_add_email"] = "";
	$_SESSION["_su_add_nama"] = "";
	$_SESSION["_su_add_nickname"] = "";
	$_SESSION["_su_add_birthday"] = "";
	$_SESSION["_su_add_telp"] = "";
	$_SESSION["_su_add_alamat"] = "";
	//======================================================
	$_SESSION["_su_edit_id"] = "";
	$_SESSION["_su_edit_action"] = "";
	$_SESSION["_su_edit_nik"] = "";
	$_SESSION["_su_edit_email"] = "";
	$_SESSION["_su_edit_nama"] = "";
	$_SESSION["_su_edit_nickname"] = "";
	$_SESSION["_su_edit_birthday"] = "";
	$_SESSION["_su_edit_telp"] = "";
	$_SESSION["_su_edit_alamat"] = "";
	//======================================================
	$_SESSION["_su_edit_id_admin"] = "";
	$_SESSION["_su_edit_action_admin"] = "";
	//======================================================
	// echo "session sudah di buat";
	
?>