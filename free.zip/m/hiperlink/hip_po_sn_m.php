<?php 
	session_start();
  $_SESSION["_po_sn_outlet"] = ""; 
  $_SESSION["_po_sn_tahun_bulan"] = ""; 



  ?>
        <script type="text/javascript">
        window.location.href="../pemasukan_outlet_sn.php";
      </script>
<?php
?>