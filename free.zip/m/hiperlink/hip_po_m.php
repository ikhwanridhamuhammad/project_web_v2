<?php 
	session_start();
  $_SESSION["_po_outlet"] = ""; 
  $_SESSION["_po_tahun_bulan"] = ""; 



  ?>
        <script type="text/javascript">
        window.location.href="../pemasukan_outlet.php";
      </script>
<?php
?>