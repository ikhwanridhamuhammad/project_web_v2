<?php 
	session_start();
  $_SESSION["_dsn_outlet"] = ""; 
  $_SESSION["_dsn_shift"]  = ""; 

  ?>
        <script type="text/javascript">
        window.location.href="../data_smart_nitro.php";
      </script>
<?php
?>