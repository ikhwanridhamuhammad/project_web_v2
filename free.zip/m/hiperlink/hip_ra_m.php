<?php 
	session_start();
  $_SESSION["_ra_karyawan"] = "ALL"; 
  $_SESSION["_ra_outlet"] = "ALL"; ?>

        <script type="text/javascript">
        window.location.href="../riwayat_absensi.php";
      </script>
<?php
?>