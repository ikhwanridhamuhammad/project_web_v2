<?php

	// include_once dirname(__FILE__) . '/dashboard.php';

?>


<?php

    error_reporting(0);
    session_start();
    include_once dirname(__FILE__) . '/dashboard.php';
?>
